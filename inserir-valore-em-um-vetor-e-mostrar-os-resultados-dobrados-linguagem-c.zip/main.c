/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>


void inserir(int a[])
{
    int i;
    for(i=0; i<3; i++)
    {
        printf("\n Digite o valor %d \t", i);
        scanf("%d", &a[i]);
    }
}

void imprimir(int b[])
{
    int i;
    for(i=0; i<3; i++)
    {
        printf("\n numeros[%d] = %d", i, (2*b[i]) );
    }
}

int main(int argoc, char** argov){
    
 int numero [3];
 printf("\n Preenchendo o vetor : \n");
 inserir(numero);
 
 printf("\n valor final");
 imprimir(numero);

    return 0;
}
